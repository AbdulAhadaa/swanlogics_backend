// server.js
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const swaggerUi = require("swagger-ui-express");
const swaggerJsdoc = require("swagger-jsdoc");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// 🔑 Gemini API Client
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// 🔹 Step 1: Define FAQs
const faq = {
  pricing: "💰 Our projects usually start from $5k. Exact cost depends on your requirements.",
  timeline: "⏳ We can deliver projects as fast as ASAP rush, or within 1, 3, or 6 months depending on scope.",
  contact: "📞 You can reach us through the quotation form or schedule a proposal call.",
  services: "🚀 We offer UI/UX Design, Website Development, Mobile App Development, E-Commerce, No-Code, and JavaScript projects.",
};

function checkFAQ(userMessage) {
  const lower = userMessage.toLowerCase();
  for (const key in faq) {
    if (lower.includes(key)) return faq[key];
  }
  return null;
}

// 🔹 API Route
app.post("/chat", async (req, res) => {
     const { message } = req.body;

     try {
       const faqAnswer = checkFAQ(message);
       if (faqAnswer) return res.json({ reply: faqAnswer });

       const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
       const result = await model.generateContent(message);

       res.json({ reply: result.response.text() });
     } catch (error) {
       console.error("❌ SERVER ERROR:", error.message); // <-- See this in terminal
       console.error("Full error:", error); // <-- Full error details
       res.status(500).json({ error: error.message });
     }
   });

// 🔹 Swagger Setup
const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Portfolio Chatbot API",
      version: "1.0.0",
      description: "API for chatting with portfolio AI assistant",
    },
  },
  apis: ["./server.js"], // where API docs live
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

/**
 * @swagger
 * /chat:
 *   post:
 *     summary: Chat with the AI assistant
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               message:
 *                 type: string
 *                 example: What services do you offer?
 *     responses:
 *       200:
 *         description: AI reply
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 reply:
 *                   type: string
 *                   example: 🚀 We offer UI/UX Design, Website Development, Mobile App Development...
 */

app.listen(5000, () =>
  console.log("✅ Gemini chatbot running at http://localhost:5000\n📖 Swagger Docs at http://localhost:5000/api-docs")
);
